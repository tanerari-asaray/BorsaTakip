package tr.borsatakip.v5.data

import tr.borsatakip.v5.model.Candle
import tr.borsatakip.v5.model.Stock

/** Veri sağlayıcılarından bağımsız ortak sözleşme. */
interface MarketDataProvider {
    val id: String
    val displayName: String
    suspend fun scan(onProgress: (done: Int, total: Int) -> Unit): List<Stock>
    suspend fun fetchOne(symbol: String): Stock?
    suspend fun listSymbols(): List<String> = emptyList()

    /**
     * Forward performans doğrulaması için zaman pencereli gerçek tarihsel veri.
     * Sağlayıcı bu yeteneği desteklemiyorsa boş liste döndürür; güncel quote tarihsel fiyat gibi kullanılmaz.
     */
    suspend fun fetchHistory(symbol: String, fromTime: Long, toTime: Long, intervalMinutes: Int = 1): List<Candle> = emptyList()

    /** Grafik için günlük gerçek geçmiş. maximumRange=true veri kaynağının sunduğu en geniş günlük aralığı ister. */
    suspend fun fetchDailyHistory(symbol: String, maximumRange: Boolean = false): List<Candle> =
        fetchOne(symbol)?.candles ?: emptyList()
}
