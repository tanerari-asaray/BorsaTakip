package tr.borsatakip.v5.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import tr.borsatakip.v5.R
import tr.borsatakip.v5.data.favorites.FavoriteStock
import tr.borsatakip.v5.model.Opportunity
import tr.borsatakip.v5.model.Stock

class FavoriteAdapter(
    private val items: List<FavoriteRow>,
    private val onRemove: (FavoriteStock) -> Unit,
    private val onOpen: (FavoriteRow) -> Unit
) : RecyclerView.Adapter<FavoriteAdapter.H>() {

    data class FavoriteRow(
        val favorite: FavoriteStock,
        val opportunity: Opportunity?,
        val stock: Stock?
    )

    class H(v: View) : RecyclerView.ViewHolder(v) {
        val symbol = v.findViewById<TextView>(R.id.favoriteSymbol)
        val company = v.findViewById<TextView>(R.id.favoriteCompany)
        val change = v.findViewById<TextView>(R.id.favoriteChange)
        val bid = v.findViewById<TextView>(R.id.favoriteBid)
        val ask = v.findViewById<TextView>(R.id.favoriteAsk)
        val signal = v.findViewById<TextView>(R.id.favoriteSignal)
        val details = v.findViewById<TextView>(R.id.favoriteDetails)
        val remove = v.findViewById<TextView>(R.id.favoriteRemove)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = H(
        LayoutInflater.from(parent.context).inflate(R.layout.item_favorite, parent, false)
    )

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: H, position: Int) {
        val row = items[position]
        val fav = row.favorite
        val opportunity = row.opportunity
        val stock = row.stock
        holder.symbol.text = "★ ${fav.symbol}"
        holder.company.text = opportunity?.companyName ?: stock?.companyName ?: fav.displayName ?: "Şirket adı veri sağlayıcıdan alınamadı"

        val changePct = opportunity?.dailyChangePct ?: stockChange(stock)
        holder.change.text = changePct?.let { "%+.2f%%".format(it) } ?: "—"
        val changeColor = when {
            changePct == null -> R.color.text_secondary
            changePct > 0.0 -> R.color.green
            changePct < 0.0 -> R.color.red
            else -> R.color.text_secondary
        }
        holder.change.setTextColor(holder.itemView.context.getColor(changeColor))

        holder.bid.text = stock?.bid?.let { "%.2f".format(it) } ?: "—"
        holder.ask.text = stock?.ask?.let { "%.2f".format(it) } ?: "—"
        holder.signal.text = opportunity?.direction ?: "DETAY"
        holder.signal.setTextColor(
            holder.itemView.context.getColor(
                when (opportunity?.direction) {
                    "LONG" -> R.color.green
                    "SHORT" -> R.color.red
                    else -> R.color.text_secondary
                }
            )
        )
        holder.details.text = opportunity?.let {
            "Nihai ${it.finalSignalScore}/100 • Risk ${it.riskScore}/100 • Veri Güveni ${it.dataConfidenceScore}/100"
        } ?: stock?.let {
            val last = it.quotePrice ?: it.candles.lastOrNull()?.close
            "Son fiyat ${last?.let { p -> "%.2f".format(p) } ?: "—"} • ${it.source}"
        } ?: "Kartı açtığınızda gerçek veri yeniden yüklenecek."

        holder.remove.text = "★ Favoriden çıkar"
        holder.remove.setOnClickListener { onRemove(fav) }
        holder.itemView.setOnClickListener { onOpen(row) }
    }

    private fun stockChange(stock: Stock?): Double? {
        stock ?: return null
        val price = stock.quotePrice ?: stock.candles.lastOrNull()?.close ?: return null
        val prev = stock.previousClose ?: return null
        if (!price.isFinite() || !prev.isFinite() || prev <= 0.0) return null
        return (price / prev - 1.0) * 100.0
    }
}
