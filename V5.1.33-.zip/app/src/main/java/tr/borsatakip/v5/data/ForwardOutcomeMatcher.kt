package tr.borsatakip.v5.data

import tr.borsatakip.v5.model.Candle

object ForwardOutcomeMatcher {
    val horizons: LinkedHashMap<String, Long> = linkedMapOf(
        "15m" to 15 * 60_000L,
        "30m" to 30 * 60_000L,
        "1h" to 60 * 60_000L,
        "4h" to 4 * 60 * 60_000L,
        "1d" to 24 * 60 * 60_000L
    )

    fun dueHorizons(signalGeneratedAt: Long, now: Long, alreadyPresent: Set<String> = emptySet()): Map<String, Long> =
        horizons.filter { (name, horizon) -> name !in alreadyPresent && signalGeneratedAt > 0L && now >= signalGeneratedAt + horizon }

    fun toleranceMs(name: String): Long = when (name) {
        "15m", "30m", "1h" -> 30 * 60_000L
        "4h" -> 90 * 60_000L
        "1d" -> 72 * 60 * 60_000L
        else -> 30 * 60_000L
    }

    fun match(candles: List<Candle>, targetTime: Long, toleranceMs: Long): Candle? =
        candles.asSequence()
            .filter { it.timestamp >= targetTime && it.timestamp <= targetTime + toleranceMs }
            .minByOrNull { it.timestamp }

    fun directionalReturnPct(signalPrice: Double, matchedPrice: Double, direction: String): Double? {
        if (!signalPrice.isFinite() || signalPrice <= 0.0 || !matchedPrice.isFinite() || matchedPrice <= 0.0) return null
        val raw = (matchedPrice / signalPrice - 1.0) * 100.0
        return if (direction.equals("SHORT", true)) -raw else raw
    }
}
