package tr.borsatakip.v5.ui

import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.widget.PopupMenu
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import tr.borsatakip.v5.analysis.ChartTimeframe
import tr.borsatakip.v5.analysis.LinearTrendAnalyzer
import tr.borsatakip.v5.data.ChartHistoryRepository
import tr.borsatakip.v5.data.ProviderRouter
import tr.borsatakip.v5.R
import tr.borsatakip.v5.model.DataMode
import tr.borsatakip.v5.model.Opportunity
import tr.borsatakip.v5.model.SignalValidity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StockDetailActivity : BaseActivity() {
    private lateinit var x: Opportunity
    private lateinit var chart: PriceChartView
    private lateinit var chartStatus: TextView
    private lateinit var trendInfoPanel: TextView
    private lateinit var chartRepository: ChartHistoryRepository
    private var chartLoadJob: Job? = null
    private var selectedTimeframe: ChartTimeframe = ChartTimeframe.ONE_DAY
    private val df = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale("tr","TR"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stock_detail)
        setupBottomNav()
        x = (if (android.os.Build.VERSION.SDK_INT >= 33) intent.getSerializableExtra("opportunity", Opportunity::class.java) else @Suppress("DEPRECATION") (intent.getSerializableExtra("opportunity") as? Opportunity))
            ?: AppSession.selected ?: run { finish(); return }
        AppSession.selected = x
        chart = findViewById(R.id.chart)
        chartStatus = findViewById(R.id.chartStatus)
        trendInfoPanel = findViewById(R.id.trendInfoPanel)
        chartRepository = ChartHistoryRepository(ProviderRouter(this))

        findViewById<TextView>(R.id.title).text = "${x.symbol}  ${money(x.price)}"
        findViewById<TextView>(R.id.subtitle).text = buildString {
            append(x.companyName ?: "Şirket adı yok")
            append(" • Günlük ${"%+.2f".format(x.dailyChangePct)}%")
        }
        findViewById<TextView>(R.id.scoreSummary).text = summaryText()
        findViewById<TextView>(R.id.overview).text = overviewText()
        bindFactorCards()
        findViewById<TextView>(R.id.technicalDetails).text = technicalText()
        findViewById<TextView>(R.id.dataQuality).text = qualityText()
        findViewById<TextView>(R.id.dataStatus).text = dataStatusText()
        findViewById<TextView>(R.id.validity).text = "SİNYAL GEÇERLİLİĞİ: ${validityLabel()}\n${x.signalValidityReason}"

        chart.signalPrice = x.price
        chart.signalTime = x.signalGeneratedAt.takeIf { it > 0L } ?: x.exchangeTimestamp.takeIf { it > 0L }
        bindTimeframeMenu()
        bindChartToggles()
        findViewById<Button>(R.id.chartZoomIn).setOnClickListener { chart.zoomIn() }
        findViewById<Button>(R.id.chartZoomOut).setOnClickListener { chart.zoomOut() }
        findViewById<Button>(R.id.chartFullscreen).setOnClickListener { openFullscreenChart() }
        chart.onRequestFullscreen = { openFullscreenChart() }
        loadTimeframe(ChartTimeframe.ONE_DAY)
        findViewById<Button>(R.id.btnTechnicalScreen).setOnClickListener { startActivity(Intent(this, TechnicalAnalysisActivity::class.java).putExtra("opportunity", x)) }
        findViewById<Button>(R.id.btnNewsScreen).setOnClickListener { startActivity(Intent(this, NewsActivity::class.java).putExtra("opportunity", x)) }
        findViewById<Button>(R.id.btnSignalScreen).setOnClickListener { startActivity(Intent(this, SignalHistoryActivity::class.java)) }
    }

    private fun bindTimeframeMenu() {
        val button = findViewById<Button>(R.id.btnTimeframeMenu)
        button.text = "◷ Zaman ▼"
        button.setOnClickListener { anchor ->
            val popup = PopupMenu(this, anchor)
            val options = listOf(
                ChartTimeframe.ONE_MIN,
                ChartTimeframe.THREE_MIN,
                ChartTimeframe.FIVE_MIN,
                ChartTimeframe.FIFTEEN_MIN,
                ChartTimeframe.ONE_HOUR,
                ChartTimeframe.ONE_DAY,
                ChartTimeframe.ALL_TIME
            )
            options.forEachIndexed { index, timeframe ->
                popup.menu.add(0, index + 1, index, "◷  ${timeframe.label}")
            }
            popup.setOnMenuItemClickListener { item ->
                val timeframe = options.getOrNull(item.itemId - 1) ?: return@setOnMenuItemClickListener false
                button.text = "◷ ${timeframe.label} ▼"
                loadTimeframe(timeframe)
                true
            }
            popup.show()
        }
    }

    private fun bindChartToggles() {
        fun bind(id: Int, activeText: String, inactiveText: String, current: () -> Boolean, apply: (Boolean) -> Unit) {
            val button = findViewById<Button>(id)
            fun refresh() {
                val active = current()
                button.text = if (active) activeText else inactiveText
                button.alpha = if (active) 1.0f else 0.62f
            }
            button.setOnClickListener {
                apply(!current())
                refresh()
            }
            refresh()
        }
        bind(R.id.toggleEma20, "EMA20 ✓", "EMA20", { chart.showEma20 }, { chart.showEma20 = it })
        bind(R.id.toggleEma50, "EMA50 ✓", "EMA50", { chart.showEma50 }, { chart.showEma50 = it })
        bind(R.id.toggleEma200, "EMA200 ✓", "EMA200", { chart.showEma200 }, { chart.showEma200 = it })
        bind(R.id.toggleBollinger, "BOLLINGER ✓", "BOLLINGER", { chart.showBollinger }, { chart.showBollinger = it })
        bind(R.id.toggleTrend, "TREND ✓", "TREND", { chart.showTrendLines }, { chart.showTrendLines = it })
        bind(R.id.toggleChannel, "KANAL ✓", "KANAL", { chart.showChannel }, { chart.showChannel = it })
    }

    private fun loadTimeframe(timeframe: ChartTimeframe) {
        selectedTimeframe = timeframe
        chartLoadJob?.cancel()
        chartStatus.text = "${timeframe.label} gerçek OHLCV verisi yükleniyor..."
        trendInfoPanel.text = "Trend analizi hazırlanıyor..."
        chartLoadJob = lifecycleScope.launch {
            runCatching {
                val candles = chartRepository.load(x.symbol, timeframe, x.candles)
                val trend = withContext(Dispatchers.Default) { LinearTrendAnalyzer.analyze(candles) }
                candles to trend
            }.onSuccess { (candles, trend) ->
                if (selectedTimeframe != timeframe) return@onSuccess
                chart.timeframeLabel = timeframe.label
                chart.candles = candles
                chart.trendAnalysis = trend
                chartStatus.text = when {
                    candles.isEmpty() -> "${timeframe.label}: gerçek OHLCV verisi bulunamadı. Sahte veri üretilmedi."
                    else -> "Zaman Dilimi: ${timeframe.label} • ${candles.size} gerçek mum • ${dateRange(candles.first().timestamp, candles.last().timestamp)} • Yakınlaştırmak için iki parmak kullanın."
                }
                trendInfoPanel.text = trendInfo(timeframe, trend)
            }.onFailure { error ->
                if (selectedTimeframe != timeframe) return@onFailure
                chart.timeframeLabel = timeframe.label
                chart.candles = emptyList()
                chart.trendAnalysis = null
                chartStatus.text = "${timeframe.label}: gerçek OHLCV verisi alınamadı • ${error.message ?: error.javaClass.simpleName}"
                trendInfoPanel.text = "Trend analizi için yeterli veri yok."
            }
        }
    }


    private fun openFullscreenChart() {
        if (chart.candles.isEmpty()) return
        startActivity(Intent(this, FullscreenChartActivity::class.java).apply {
            putExtra("candles", ArrayList(chart.candles))
            putExtra("timeframe", selectedTimeframe.label)
            putExtra("signalPrice", x.price)
            putExtra("signalTime", x.signalGeneratedAt.takeIf { it > 0L } ?: x.exchangeTimestamp)
        })
    }

    private fun trendInfo(timeframe: ChartTimeframe, r: LinearTrendAnalyzer.Result): String {
        val main = r.main
        if (main == null) return "Zaman Dilimi: ${timeframe.label}\n${r.message ?: "Trend analizi için yeterli veri yok."}"
        val strength = sequenceOf(r.support, r.resistance, r.main).filterNotNull().maxByOrNull { it.strengthScore } ?: main
        val breakoutDetail = when (r.breakout) {
            LinearTrendAnalyzer.Breakout.UP -> "YUKARI KIRILIM • ${r.volumeConfirmation.label} hacim teyidi"
            LinearTrendAnalyzer.Breakout.DOWN -> "AŞAĞI KIRILIM • ${r.volumeConfirmation.label} hacim teyidi"
            LinearTrendAnalyzer.Breakout.WAITING -> "TEYİT BEKLENİYOR • ${r.volumeConfirmation.label} hacim"
            LinearTrendAnalyzer.Breakout.NONE -> "KIRILIM YOK"
        }
        return buildString {
            append("Zaman Dilimi: ${timeframe.label}\n")
            append("Ana Trend: ${main.direction.label}\n")
            append("Trend Gücü: ${strength.strength.label} (${strength.strengthScore}/100)\n")
            append("Ana Eğim: ${"%.6f".format(main.slope)} • R²: ${"%.3f".format(main.r2)}\n")
            append("Temas: ${strength.contactCount} • Son temas: ${strength.lastContactIndex?.let { "${r.candleCount - 1 - it} mum önce" } ?: "yok"}\n")
            append("Destek Trend: ${r.supportNow?.let { "%.2f".format(it) } ?: "yok"}\n")
            append("Direnç Trend: ${r.resistanceNow?.let { "%.2f".format(it) } ?: "yok"}\n")
            append("Trend Kırılımı: $breakoutDetail")
            r.breakoutPct?.let { append(" • ${"%+.2f".format(it)}%") }
        }
    }

    private fun dateRange(first: Long, last: Long): String = "${df.format(Date(first))} – ${df.format(Date(last))}"

    private fun summaryText():String {
        val strength = when {
            x.finalSignalScore >= 85 -> "YÜKSEK GÜÇ"
            x.finalSignalScore >= 70 -> "İZLE"
            x.finalSignalScore >= 60 -> "ZAYIF SİNYAL"
            else -> "DÜŞÜK GÜÇ"
        }
        return "${x.direction}\nNihai Sinyal ${x.finalSignalScore}/100 • $strength\nTeknik Skor ${x.score}/100 • Risk ${x.riskScore}/100 • Veri Güveni ${x.dataConfidenceScore}/100 (${x.dataConfidenceLabel})\n${validityLabel()}"
    }

    private fun overviewText():String {
        val t = x.technical
        val emaState = when {
            listOf(t.ema20,t.ema50,t.ema200).all { it != null } && x.price < t.ema20!! && t.ema20!! < t.ema50!! && t.ema50!! < t.ema200!! ->
                "Fiyat EMA20, EMA50 ve EMA200 seviyelerinin altında; mevcut trend aşağı yönlü."
            listOf(t.ema20,t.ema50,t.ema200).all { it != null } && x.price > t.ema20!! && t.ema20!! > t.ema50!! && t.ema50!! > t.ema200!! ->
                "Fiyat EMA20, EMA50 ve EMA200 seviyelerinin üzerinde; mevcut trend yukarı yönlü."
            else -> "EMA dizilimi tek yönlü güçlü trend teyidi vermiyor."
        }
        val volume = x.technical.volumeRatio?.let {
            if (it < 0.8) "İşlem hacmi zayıf olduğu için sinyal teyidi azalıyor." else "Hacim sinyal değerlendirmesine veri sağlıyor."
        } ?: "Hacim teyidi doğrulanamadı."
        return "$emaState $volume Nihai Sinyal ${x.finalSignalScore}/100 bir başarı olasılığı değildir; veri ve teknik koşulların mevcut sürümdeki birleşik skorudur."
    }

    private fun bindFactorCards() {
        val t = x.technical
        val trend = when {
            t.ema20 != null && t.ema50 != null && t.ema200 != null && x.price < t.ema20 && t.ema20 < t.ema50 && t.ema50 < t.ema200 -> "NEGATİF\nFiyat EMA20/50/200 altında. SHORT yönünü destekliyor."
            t.ema20 != null && t.ema50 != null && t.ema200 != null && x.price > t.ema20 && t.ema20 > t.ema50 && t.ema50 > t.ema200 -> "POZİTİF\nFiyat EMA20/50/200 üzerinde. LONG yönünü destekliyor."
            else -> "KARIŞIK\nEMA dizilimi güçlü tek yön teyidi vermiyor."
        }
        findViewById<TextView>(R.id.trendCard).text = "TREND\n$trend"

        val rsi = t.rsi14
        val momentum = when {
            rsi == null -> "YETERSİZ VERİ\nRSI14 hesaplanamadı."
            rsi < 30 -> "AŞIRI SATIM BÖLGESİNE YAKIN/ALTINDA\nRSI14 ${fmt(rsi)}. Tepki hareketi riski izlenmeli."
            rsi < 48 -> "ZAYIF\nRSI14 ${fmt(rsi)}. Alıcı momentumu zayıf."
            rsi <= 68 -> "DENGELİ/POZİTİF\nRSI14 ${fmt(rsi)}. Momentum aşırı bölge dışında."
            else -> "YÜKSEK\nRSI14 ${fmt(rsi)}. Aşırı alım/geri çekilme riski izlenmeli."
        }
        findViewById<TextView>(R.id.momentumCard).text = "MOMENTUM\n$momentum"

        val macd = if (t.macd != null && t.macdSignal != null) {
            val state = if (t.macd >= t.macdSignal) "POZİTİF" else "NEGATİF"
            "$state\nMACD ${fmt(t.macd)} / Signal ${fmt(t.macdSignal)}. Kısa vadeli momentum ${if (state=="POZİTİF") "yukarı" else "aşağı"} yönde."
        } else "YETERSİZ VERİ\nMACD/Signal hesaplanamadı."
        findViewById<TextView>(R.id.macdCard).text = "MACD\n$macd"

        val volume = t.volumeRatio?.let { ratio ->
            val state = when { ratio >= 1.5 -> "GÜÇLÜ TEYİT"; ratio >= 1.0 -> "ORTA TEYİT"; else -> "ZAYIF TEYİT" }
            "$state\nHacim ${"%.2f".format(ratio)}x. ${if (ratio < 1.0) "Düşük katılım sinyal teyidini azaltıyor." else "Hacim katılımı sinyal değerlendirmesini destekliyor."}"
        } ?: "YETERSİZ VERİ\nHacim oranı hesaplanamadı."
        findViewById<TextView>(R.id.volumeCard).text = "HACİM\n$volume"

        findViewById<TextView>(R.id.extraCard).text = buildString {
            append("EK FAKTÖRLER\n")
            append("20S Hacim Ağırlıklı Ort.: ${fmt(t.vwap)} • ${if (t.vwap != null) if (x.price >= t.vwap) "fiyat üzerinde" else "fiyat altında" else "veri yok"}\n")
            append("VWMA: ${fmt(t.vwma)}\n")
            append("ATR14: ${fmt(t.atr14)} • volatilite/risk girdisi\n")
            append("Destek: ${fmt(t.support)} • Direnç: ${fmt(t.resistance)}")
        }
    }

    private fun technicalText():String {
        val t=x.technical
        return "EMA20: ${fmt(t.ema20)}\nEMA50: ${fmt(t.ema50)}\nEMA200: ${fmt(t.ema200)}\nRSI14: ${fmt(t.rsi14)}\nMACD: ${fmt(t.macd)}\nSignal: ${fmt(t.macdSignal)}\nATR14: ${fmt(t.atr14)}\n20S Hacim Ağırlıklı Ort.: ${fmt(t.vwap)}\nVWMA: ${fmt(t.vwma)}\nHacim oranı: ${t.volumeRatio?.let { "%.2fx".format(it) } ?: "Veri yok"}\nBollinger alt/üst: ${fmt(t.bbLower)} / ${fmt(t.bbUpper)}\nDestek/Direnç: ${fmt(t.support)} / ${fmt(t.resistance)}"
    }

    private fun qualityText():String {
        fun mark(ok:Boolean)=if(ok)"✓" else "⚠ Veri yok"
        val hasPrice=x.price.isFinite()&&x.price>0
        val hasVol=x.technical.volumeRatio!=null
        val hasOhlcv=x.candles.size>=220
        val hasKap=!x.kapLabel.equals("Veri yok",true)&&x.kapLabel.isNotBlank()
        val hasLevels=x.support!=null&&x.resistance!=null
        val hasVwap=x.technical.vwap!=null
        return "VERİ GÜVENİ ${x.dataConfidenceScore}/100 (${x.dataConfidenceLabel})\nFiyat ${mark(hasPrice)}\nHacim ${mark(hasVol)}\nOHLCV ${mark(hasOhlcv)}\nKAP ${mark(hasKap)}\nDestek/Direnç ${mark(hasLevels)}\n20S Hacim Ağırlıklı Ort. ${mark(hasVwap)}\nEksik alanlar uydurulmaz ve Veri Güveni ile Nihai Sinyal birbirinin yerine kullanılmaz."
    }

    private fun dataStatusText():String {
        val measured = if (x.receivedElapsedRealtime > 0L) {
            val elapsed=(SystemClock.elapsedRealtime()-x.receivedElapsedRealtime).coerceAtLeast(0L)
            val atReceipt=if(x.receivedAt>0&&x.exchangeTimestamp>0)(x.receivedAt-x.exchangeTimestamp).coerceAtLeast(0L) else 0L
            formatAge(atReceipt+elapsed)
        } else "yeniden başlatma sonrası monotonic yaş doğrulanamıyor"
        return "Kaynak: ${x.source}\nVeri Modu: ${x.dataMode.name}\nPiyasa Veri Zamanı: ${time(x.exchangeTimestamp)}\nUygulamaya Ulaşma: ${time(x.receivedAt)}\nÖlçülen Veri Yaşı: $measured\nSağlayıcı gecikmesi: ${x.delaySeconds?.let { "$it sn" } ?: "bilinmiyor"}\nTarama başladı: ${time(x.scanStartedAt)}\nTarama tamamlandı: ${time(x.scanCompletedAt)}\nScanRun: ${x.scanRunId ?: "yok"}\nNot: Uygulamaya ulaşma süresi, tek başına piyasa gecikmesi olarak yorumlanmaz."
    }

    private fun validityLabel() = when(x.signalValidity) {
        SignalValidity.VALID -> "DOĞRULANMIŞ FIRSAT"
        SignalValidity.WATCH -> "İZLEME"
        SignalValidity.INSUFFICIENT -> "YETERSİZ VERİ"
        SignalValidity.REJECTED -> "REDDEDİLDİ"
    }
    private fun time(v:Long)=if(v>0)df.format(Date(v)) else "bilinmiyor"
    private fun money(v:Double)=if(v.isFinite())"%.2f TL".format(v) else "Veri yok"
    private fun fmt(v:Double?)=v?.takeIf{it.isFinite()}?.let{"%.2f".format(it)}?:"Veri yok"
    private fun formatAge(ms:Long)=when { ms<60_000L->"${ms/1000L} sn"; ms<3_600_000L->"${ms/60_000L} dk"; else->"${ms/3_600_000L} sa" }
}
