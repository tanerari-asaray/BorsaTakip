package tr.borsatakip.v5.ui

import android.os.Bundle
import android.widget.TextView
import tr.borsatakip.v5.R

class ViopDetailActivity : BaseActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_viop_detail)
        setupBottomNav()
        val o = AppSession.selectedViopOpportunity
        val c = o?.contract ?: AppSession.selectedViopContract
        findViewById<TextView>(R.id.viopDetailSubtitle).text = c?.let {
            "${it.symbol.uppercase()} • ${it.underlying} • ${it.expiry}"
        } ?: "Seçili sözleşme yok"
        findViewById<TextView>(R.id.viopDetailSignal).text = when {
            o != null -> "${o.direction} • Nihai Sinyal ${o.finalScore}/100"
            c != null -> "ANALİZ BEKLENİYOR"
            else -> "VERİ YOK"
        }
        findViewById<TextView>(R.id.viopDetailPrice).text = o?.quote?.let {
            "${"%.2f".format(it.price)} • ${it.dailyChangePct?.let { p -> "%+.2f%%".format(p) } ?: "VERİ YOK"}"
        } ?: c?.lastPrice?.let { "Fiyat ${"%.2f".format(it)}" } ?: "Fiyat mevcut değil"
        findViewById<TextView>(R.id.viopDetailBody).text = when {
            o != null -> buildString {
                append("Teknik ${o.technicalScore}/100 • Risk ${o.riskScore}/100 • Likidite ${o.liquidityScore}/100\n")
                append("Hacim: ${o.quote.volume ?: "VERİ YOK"} • Açık Pozisyon: ${o.quote.openInterest ?: "VERİ YOK"}\n")
                append("20S Hacim Ağırlıklı Ort.: ${o.technical.vwap ?: "VERİ YOK"} • Destek: ${o.technical.support ?: "VERİ YOK"} • Direnç: ${o.technical.resistance ?: "VERİ YOK"}\n")
                append("Veri zamanı: ${o.quote.exchangeTimestamp} • Yaş: ${o.dataAgeMs} ms\n")
                append("Kaynak: ${o.quote.source}\n\n")
                append("Basis/Momentum kaynaktan gelmiyorsa gösterilmez.")
            }
            c != null -> "Hacim: ${c.volume ?: "VERİ YOK"} • Açık Pozisyon: ${c.openInterest ?: "VERİ YOK"}\n" +
                "Veri modu: ${c.dataMode} • Kaynak: ${c.providerLabel}\n" +
                "Durum: ${c.validity} • ${c.validityReason}\n\n" +
                "Analiz üretmeden LONG/SHORT veya skor gösterilmez."
            else -> "VİOP Sözleşmeleri ekranından bir sözleşme seçin."
        }
    }
}
