package tr.borsatakip.v5.ui
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import tr.borsatakip.v5.R
import tr.borsatakip.v5.data.SettingsStore
class NotificationsActivity:BaseActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_notifications);setupBottomNav();val s=SettingsStore(this);findViewById<TextView>(R.id.notificationState).text=if(s.notifications)"AÇIK" else "KAPALI";findViewById<TextView>(R.id.notificationRefresh).text="Yenileme aralığı: ${s.refreshMinutes} dk";findViewById<TextView>(R.id.notificationEmpty).text="Bu sürüm kalıcı bildirim geçmişi üretmiyor. Var olmayan bildirim kaydı uydurulmaz. Sistem bildirimi üretildiğinde ilgili hisse/VİOP detayına yönlendirme yapılır.";findViewById<Button>(R.id.notificationSettings).setOnClickListener{startActivity(Intent(this,SettingsActivity::class.java))}}}
