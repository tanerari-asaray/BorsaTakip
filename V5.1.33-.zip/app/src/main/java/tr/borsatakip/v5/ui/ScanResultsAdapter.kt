package tr.borsatakip.v5.ui

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.recyclerview.widget.RecyclerView
import tr.borsatakip.v5.R
import tr.borsatakip.v5.model.DataMode
import tr.borsatakip.v5.model.Opportunity
import tr.borsatakip.v5.model.SignalValidity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Tarama Sonuçları ekranına özel sunum katmanı.
 * Opportunity modelini veya sinyal hesaplarını değiştirmez; yalnızca mevcut gerçek değerleri
 * okunabilir bölümlere ayırır.
 */
class ScanResultsAdapter(
    private val items: List<Opportunity>,
    private val click: (Opportunity) -> Unit
) : RecyclerView.Adapter<ScanResultsAdapter.Holder>() {

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val company: TextView = v.findViewById(R.id.company)
        val symbol: TextView = v.findViewById(R.id.symbol)
        val direction: TextView = v.findViewById(R.id.directionBadge)
        val strengthBar: ProgressBar = v.findViewById(R.id.strengthBar)
        val strengthValue: TextView = v.findViewById(R.id.strengthValue)
        val strengthTier: TextView = v.findViewById(R.id.strengthTier)
        val technicalScore: TextView = v.findViewById(R.id.technicalScore)
        val riskScore: TextView = v.findViewById(R.id.riskScore)
        val confidenceScore: TextView = v.findViewById(R.id.confidenceScore)
        val dataMode: TextView = v.findViewById(R.id.dataMode)
        val source: TextView = v.findViewById(R.id.source)
        val timeInfo: TextView = v.findViewById(R.id.timeInfo)
        val levels: TextView = v.findViewById(R.id.levels)
        val coverage: TextView = v.findViewById(R.id.coverage)
        val reason: TextView = v.findViewById(R.id.reason)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_scan_result, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        val symbol = item.symbol.trim().uppercase(Locale.ROOT)
        val company = item.companyName?.trim().takeUnless { it.isNullOrBlank() } ?: symbol
        val direction = item.direction.trim().uppercase(Locale.ROOT)
        val score = item.finalSignalScore.coerceIn(0, 100)

        holder.company.text = company
        holder.symbol.text = symbol
        holder.direction.text = direction
        holder.direction.contentDescription = "Sinyal yönü: $direction"
        holder.strengthBar.progress = score
        holder.strengthValue.text = "$score/100"
        holder.strengthTier.text = "${strengthLabel(score)} • ${validityLabel(item.signalValidity)}"
        holder.technicalScore.text = "TEKNİK SKOR\n${item.score.coerceIn(0, 100)}/100"
        holder.riskScore.text = "RİSK\n${item.riskScore.coerceIn(0, 100)}/100"
        holder.confidenceScore.text = "VERİ GÜVENİ\n${item.dataConfidenceScore.coerceIn(0, 100)}/100\n${item.dataConfidenceLabel}"

        holder.dataMode.text = dataModeLabel(item.dataMode)
        holder.source.text = buildString {
            append("Kaynak: ${item.source}")
            item.delaySeconds?.let { append(" • Sağlayıcı gecikmesi: $it sn") }
        }

        val marketTime = formatTimestamp(item.exchangeTimestamp)
        val receivedTime = formatTimestamp(item.receivedAt)
        holder.timeInfo.text = buildString {
            append("Piyasa zamanı: $marketTime\n")
            append("Veri yaşı: ${measuredAge(item)}")
            if (receivedTime != "bilinmiyor") append(" • Uygulamaya geliş: $receivedTime")
        }

        holder.levels.text = buildString {
            append("Destek: ${priceOrMissing(item.support)}")
            append("   •   Direnç: ${priceOrMissing(item.resistance)}")
        }

        val hasPrice = item.price.isFinite() && item.price > 0.0
        val hasVolume = !item.volumeLabel.equals("Veri yok", true) && item.volumeLabel.isNotBlank()
        val hasOhlcv = item.candles.isNotEmpty()
        val hasKap = !item.kapLabel.equals("Veri yok", true) && item.kapLabel.isNotBlank()
        holder.coverage.text = "Veri kapsamı: Fiyat ${mark(hasPrice)} • Hacim ${mark(hasVolume)} • OHLCV ${mark(hasOhlcv)} • KAP ${mark(hasKap)}"

        val factors = item.scoreBreakdown.asSequence()
            .takeWhile { !it.startsWith("KAP:") }
            .filter { it.contains(": +") }
            .map { it.substringBefore(":").trim() }
            .distinct()
            .take(4)
            .toList()
        holder.reason.text = buildString {
            append("Sinyal özeti: ")
            append(if (factors.isEmpty()) item.signalValidityReason else factors.joinToString(" • "))
        }

        applyVisuals(holder, direction, score)
        holder.itemView.setOnClickListener { click(item) }
    }

    private fun applyVisuals(holder: Holder, direction: String, score: Int) {
        val isLong = direction.equals("LONG", true)
        val accent = if (isLong) Color.rgb(0, 240, 128) else Color.rgb(255, 69, 69)
        val dark = if (isLong) Color.rgb(0, 38, 31) else Color.rgb(48, 12, 18)
        val strength = score / 100f
        val border = ColorUtils.blendARGB(accent, Color.WHITE, strength * 0.25f)
        holder.itemView.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(holder.itemView, 14f)
            setColor(ColorUtils.blendARGB(Color.rgb(6, 38, 58), dark, 0.35f))
            setStroke(dp(holder.itemView, if (score >= 85) 2f else 1f).toInt().coerceAtLeast(1), border)
        }
        holder.direction.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(holder.itemView, 12f)
            setColor(ColorUtils.setAlphaComponent(accent, 42))
            setStroke(dp(holder.itemView, 1.5f).toInt().coerceAtLeast(1), accent)
        }
        holder.direction.setTextColor(accent)
        holder.strengthValue.setTextColor(accent)
        holder.strengthBar.progressTintList = ColorStateList.valueOf(accent)
        holder.strengthBar.progressBackgroundTintList = ColorStateList.valueOf(ColorUtils.setAlphaComponent(accent, 40))
    }

    private fun strengthLabel(score: Int): String = when {
        score >= 90 -> "ÇOK GÜÇLÜ SİNYAL"
        score >= 85 -> "GÜÇLÜ SİNYAL"
        score >= 70 -> "ORTA SİNYAL"
        else -> "ZAYIF SİNYAL"
    }

    private fun validityLabel(validity: SignalValidity): String = when (validity) {
        SignalValidity.VALID -> "Doğrulanmış fırsat"
        SignalValidity.WATCH -> "İzleme"
        SignalValidity.INSUFFICIENT -> "Yetersiz veri"
        SignalValidity.REJECTED -> "Reddedildi"
    }

    private fun dataModeLabel(mode: DataMode): String = when (mode) {
        DataMode.REALTIME -> "CANLI VERİ"
        DataMode.DELAYED -> "GECİKMELİ VERİ"
        DataMode.EOD -> "GÜN SONU VERİSİ"
        DataMode.UNVERIFIED -> "DOĞRULANMAMIŞ VERİ"
    }

    private fun measuredAge(item: Opportunity): String {
        if (item.receivedElapsedRealtime <= 0L) return "yeniden başlatma sonrası doğrulanamıyor"
        val elapsedSinceReceipt = (SystemClock.elapsedRealtime() - item.receivedElapsedRealtime).coerceAtLeast(0L)
        val ageAtReceipt = if (item.exchangeTimestamp > 0L && item.receivedAt > 0L) {
            (item.receivedAt - item.exchangeTimestamp).coerceAtLeast(0L)
        } else 0L
        return formatAge(ageAtReceipt + elapsedSinceReceipt)
    }

    private fun formatTimestamp(value: Long): String = if (value > 0L) {
        SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(Date(value))
    } else "bilinmiyor"

    private fun formatAge(ms: Long): String = when {
        ms < 60_000L -> "${ms / 1000L} sn"
        ms < 3_600_000L -> "${ms / 60_000L} dk"
        ms < 86_400_000L -> "${ms / 3_600_000L} sa"
        else -> "${ms / 86_400_000L} gün"
    }

    private fun priceOrMissing(value: Double?): String = value?.takeIf { it.isFinite() }?.let { "%.2f".format(it) } ?: "veri yok"
    private fun mark(ok: Boolean): String = if (ok) "✓" else "—"
    private fun dp(view: View, value: Float): Float = value * view.resources.displayMetrics.density
}
