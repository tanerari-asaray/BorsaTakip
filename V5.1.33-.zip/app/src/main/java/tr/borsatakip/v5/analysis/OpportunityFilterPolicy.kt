package tr.borsatakip.v5.analysis

import tr.borsatakip.v5.model.Opportunity
import tr.borsatakip.v5.model.SignalValidity

enum class OpportunityFilter {
    ALL, A_CLASS, BREAKOUT, REVERSAL, SQUEEZE, PULLBACK, VOLUME, TREND,
    LONG, SHORT, HIGH_POWER
}

object OpportunityFilterPolicy {
    private fun publishable(x: Opportunity) =
        x.signalValidity == SignalValidity.VALID || x.signalValidity == SignalValidity.WATCH

    fun apply(items: List<Opportunity>, filter: OpportunityFilter): List<Opportunity> {
        val sorted = items.filter(::publishable).sortedWith(
            compareByDescending<Opportunity> { Opportunity2Presentation.from(it).klass == "A SINIFI" }
                .thenByDescending { it.finalSignalScore }
                .thenByDescending { it.dataConfidenceScore }
                .thenByDescending { Opportunity2Presentation.from(it).riskReward ?: -1.0 }
                .thenBy { it.riskScore }
                .thenBy { it.symbol }
        )
        return when (filter) {
            OpportunityFilter.ALL -> sorted
            OpportunityFilter.A_CLASS -> sorted.filter { Opportunity2Presentation.from(it).klass == "A SINIFI" }
            OpportunityFilter.BREAKOUT -> sorted.filter { Opportunity2Presentation.from(it).setup.contains("KIRILIM") }
            OpportunityFilter.REVERSAL -> sorted.filter { Opportunity2Presentation.from(it).setup.contains("DİPTEN DÖNÜŞ") || Opportunity2Presentation.from(it).setup.contains("DESTEKTE TEPKİ") }
            OpportunityFilter.SQUEEZE -> sorted.filter { Opportunity2Presentation.from(it).setup.contains("SIKIŞMA") }
            OpportunityFilter.PULLBACK -> sorted.filter { Opportunity2Presentation.from(it).setup.contains("GERİ ÇEKİLME") }
            OpportunityFilter.VOLUME -> sorted.filter { (it.technical.volumeRatio ?: 0.0) >= 1.5 }
            OpportunityFilter.TREND -> sorted.filter {
                val t = it.technical
                val p = it.price
                (t.ema20 != null && t.ema50 != null && t.ema200 != null) &&
                    ((p > t.ema20 && t.ema20 > t.ema50 && t.ema50 > t.ema200) ||
                     (p < t.ema20 && t.ema20 < t.ema50 && t.ema50 < t.ema200))
            }
            OpportunityFilter.LONG -> sorted.filter { it.direction.equals("LONG", true) }
            OpportunityFilter.SHORT -> sorted.filter { it.direction.equals("SHORT", true) }
            OpportunityFilter.HIGH_POWER -> sorted.filter { it.finalSignalScore >= 85 }
        }
    }
}
