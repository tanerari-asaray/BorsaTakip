package tr.borsatakip.v5

import android.app.Application
import android.util.Log
import tr.borsatakip.v5.data.SettingsStore
import tr.borsatakip.v5.worker.WorkScheduler

class BorsaTakipApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) installDebugCrashLogger()
        val s = SettingsStore(this)
        WorkScheduler.reconcile(this, s.notifications, s.refreshMinutes)
    }

    private fun installDebugCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e("BIST_CRASH", "[BIST_CRASH] thread=${thread.name} exception=${throwable::class.java.name} message=${throwable.message}", throwable)
            previous?.uncaughtException(thread, throwable)
        }
    }
}
