package tr.borsatakip.v5.ui

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch
import tr.borsatakip.v5.R
import tr.borsatakip.v5.data.favorites.FavoriteRepository

class StocksActivity : BaseActivity() {
    private lateinit var repo: FavoriteRepository
    private lateinit var list: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stocks)
        setupBottomNav()
        repo = FavoriteRepository.get(this)
        list = findViewById(R.id.stocksList)
        list.layoutManager = LinearLayoutManager(this)
        val items = AppSession.lastOpportunities
        findViewById<TextView>(R.id.stocksStatus).text = if (items.isEmpty()) {
            "VERİ YOK • Önce gerçek BIST taraması çalıştırın."
        } else {
            "${items.size} gerçek analiz sonucu • kart seçimi Hisse Detay'a gider"
        }
        lifecycleScope.launch {
            repo.migrateLegacyIfNeeded()
            bindList()
        }
    }

    private suspend fun bindList() {
        val items = AppSession.lastOpportunities
        val favorites = repo.symbols()
        list.adapter = OpportunityAdapter(
            items,
            favorites,
            click = { x ->
                AppSession.selected = x
                startActivity(Intent(this, StockDetailActivity::class.java).putExtra("opportunity", x))
            },
            toggleFavorite = { x ->
                lifecycleScope.launch {
                    repo.toggle(x.symbol, x.companyName)
                    bindList()
                }
            }
        )
    }

    override fun onResume() {
        super.onResume()
        if (::repo.isInitialized && ::list.isInitialized) lifecycleScope.launch { bindList() }
    }
}
