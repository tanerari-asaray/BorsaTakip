package tr.borsatakip.v5.analysis

import tr.borsatakip.v5.model.Opportunity

data class Opportunity2Presentation(
    val klass: String,
    val setup: String,
    val riskReward: Double?,
    val timing: String,
    val reasons: List<String>,
    val risks: List<String>
) {
    companion object {
        fun from(x: Opportunity): Opportunity2Presentation {
            fun value(prefix: String) = x.scoreBreakdown.firstOrNull { it.startsWith(prefix) }?.substringAfter(prefix)?.trim()
            val klass = value("CLASS=") ?: when {
                x.finalSignalScore >= 85 && x.dataConfidenceScore >= 75 -> "A SINIFI"
                x.finalSignalScore >= 70 -> "B SINIFI"
                else -> "İZLE"
            }
            val setup = value("SETUP=") ?: "TEKNİK YAPI"
            val rr = value("RR=")?.toDoubleOrNull()
            val timing = value("TIMING=") ?: "DEĞERLENDİRİLMEDİ"
            val reasons = x.scoreBreakdown.filter { it.startsWith("WHY=") }.map { it.substringAfter("WHY=") }
            val risks = x.scoreBreakdown.filter { it.startsWith("RISK_NOTE=") }.map { it.substringAfter("RISK_NOTE=") }
            return Opportunity2Presentation(klass, setup, rr, timing, reasons, risks)
        }
    }
}
