package tr.borsatakip.v5.data

import android.content.Context
import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import tr.borsatakip.v5.model.Candle
import tr.borsatakip.v5.model.Stock
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.URLEncoder
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.SSLException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class ProviderException(
    val code: ProviderFailureCode,
    message: String,
    cause: Throwable? = null
) : Exception(message, cause)

class MobileMarketDataProvider(context: Context) : MarketDataProvider {
    private val settings = SettingsStore(context)
    override val id = "mobile_backend"
    override val displayName = "Üretim canlı veri servisi"
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
        .build()

    override suspend fun scan(onProgress: (done: Int, total: Int) -> Unit): List<Stock> = withContext(Dispatchers.IO) {
        ensureConfigured()
        val symbols = loadSymbols()
        if (symbols.isEmpty()) throw ProviderException(ProviderFailureCode.EMPTY_DATA, "BIST sembol listesi alınamadı.")
        Log.i(TAG, "[BIST_SCAN] TOTAL=${symbols.size} batchSize=$BATCH_SIZE")
        val out = mutableListOf<Stock>()
        var done = 0
        val batches = symbols.chunked(BATCH_SIZE)
        for ((batchIndex, batch) in batches.withIndex()) {
            val batchResult = try {
                withTimeoutOrNull(BATCH_TIMEOUT_MS) {
                    val encoded = URLEncoder.encode(batch.joinToString(","), "UTF-8")
                    getJson("/v1/bist/snapshot-batch?symbols=$encoded")
                } ?: throw ProviderException(ProviderFailureCode.NETWORK_TIMEOUT, "Batch ${batchIndex + 1}/${batches.size} zaman aşımına uğradı.")
            } catch (ce: CancellationException) {
                throw ce
            } catch (pe: ProviderException) {
                Log.w(TAG, "[BIST_SCAN] BATCH_FAILED index=${batchIndex + 1} size=${batch.size} code=${pe.code} message=${pe.message}")
                if (pe.code in SYSTEMIC_FAILURES) throw pe
                done = (done + batch.size).coerceAtMost(symbols.size)
                onProgress(done, symbols.size)
                continue
            }
            val items = batchResult.optJSONArray("items") ?: throw ProviderException(ProviderFailureCode.EMPTY_DATA, "Batch tarama yanıtında items alanı yok.")
            val expected = batch.toSet()
            val returned = mutableSetOf<String>()
            for (i in 0 until items.length()) {
                val row = items.optJSONObject(i) ?: throw ProviderException(ProviderFailureCode.EMPTY_DATA, "Batch öğesi nesne değil.")
                val requested = row.optString("symbol").trim().uppercase()
                if (requested !in expected || !returned.add(requested)) throw ProviderException(ProviderFailureCode.EMPTY_DATA, "Batch sözleşmesi bozuk: beklenmeyen veya tekrarlanan sembol $requested")
                if (row.has("error")) {
                    val errorObj = row.optJSONObject("error")
                    val code = errorObj?.optString("code").orEmpty()
                    Log.w(TAG, "[BIST_SCAN] SYMBOL_FAILED $requested $code")
                    val systemic = when (code.uppercase()) {
                        "AUTH_ERROR", "AUTH_NOT_CONFIGURED", "TLS_ERROR", "DNS_ERROR", "NETWORK_TIMEOUT", "RATE_LIMIT", "HTTP_ERROR", "SERVER_ERROR", "NOT_CONFIGURED" -> true
                        else -> false
                    }
                    if (systemic) throw ProviderException(
                        when (code.uppercase()) {
                            "AUTH_ERROR", "AUTH_NOT_CONFIGURED" -> ProviderFailureCode.AUTH_ERROR
                            "TLS_ERROR" -> ProviderFailureCode.TLS_ERROR
                            "DNS_ERROR" -> ProviderFailureCode.DNS_ERROR
                            "NETWORK_TIMEOUT" -> ProviderFailureCode.NETWORK_TIMEOUT
                            "RATE_LIMIT" -> ProviderFailureCode.RATE_LIMIT
                            else -> ProviderFailureCode.SERVER_ERROR
                        },
                        errorObj?.optString("message").ifNullOrBlank("Batch provider error: $code")
                    )
                    continue
                }
                val q = row.optJSONObject("quote") ?: throw ProviderException(ProviderFailureCode.EMPTY_DATA, "$requested quote alanı eksik.")
                val h = row.optJSONObject("history") ?: throw ProviderException(ProviderFailureCode.EMPTY_DATA, "$requested history alanı eksik.")
                try { out += parseStockPair(requested, q, h) } catch (pe: ProviderException) {
                    if (pe.code in SYSTEMIC_FAILURES) throw pe
                    Log.w(TAG, "[BIST_SCAN] SYMBOL_SKIPPED $requested ${pe.code}: ${pe.message}")
                }
            }
            if (returned != expected || items.length() != batch.size) throw ProviderException(ProviderFailureCode.EMPTY_DATA, "Batch count/symbol mismatch: requested=${batch.size} returned=${items.length()} unique=${returned.size}")
            done=(done+batch.size).coerceAtMost(symbols.size); onProgress(done,symbols.size)
        }
        out
    }

    override suspend fun fetchOne(symbol: String): Stock? = withContext(Dispatchers.IO) {
        ensureConfigured()
        withTimeout(20_000) { fetchStock(normalizeSymbol(symbol)) }
    }

    override suspend fun fetchHistory(symbol: String, fromTime: Long, toTime: Long, intervalMinutes: Int): List<Candle> = withContext(Dispatchers.IO) {
        ensureConfigured()
        if (fromTime <= 0L || toTime <= fromTime) return@withContext emptyList()
        val requested = normalizeSymbol(symbol)
        val safeInterval = intervalMinutes.coerceIn(1, 60)
        val encoded = URLEncoder.encode(requested, "UTF-8")
        val json = getJson("/v1/bist/history-window/$encoded?from=$fromTime&to=$toTime&interval=${safeInterval}m")
        requireMatchingSymbol(requested, json.optString("symbol"), "history-window")
        val candles = parseCandlesStrict(json.optJSONArray("candles") ?: JSONArray(), minimum = 1)
        candles.filter { it.timestamp in fromTime..toTime }.sortedBy { it.timestamp }
    }


    override suspend fun fetchDailyHistory(symbol: String, maximumRange: Boolean): List<Candle> = withContext(Dispatchers.IO) {
        ensureConfigured()
        val requested = normalizeSymbol(symbol)
        val encoded = URLEncoder.encode(requested, "UTF-8")
        val range = if (maximumRange) "max" else "1y"
        val json = getJson("/v1/bist/history/$encoded?range=$range&interval=1d")
        requireMatchingSymbol(requested, json.optString("symbol"), "daily-history")
        parseCandlesStrict(json.optJSONArray("candles") ?: JSONArray(), minimum = 1).sortedBy { it.timestamp }
    }

    override suspend fun listSymbols(): List<String> = loadSymbols()

    private suspend fun loadSymbols(): List<String> {
        val json = getJson("/v1/bist/symbols")
        val items = json.optJSONArray("items") ?: throw ProviderException(ProviderFailureCode.EMPTY_DATA, "BIST sembol yanıtı boş.")
        val symbols = (0 until items.length()).mapNotNull { i ->
            items.optString(i).trim().uppercase().takeIf { it.matches(Regex("[A-Z0-9_]{3,12}")) }
        }.distinct()
        if (symbols.isNotEmpty()) {
            settings.cachedBistSymbols = symbols.toSet()
            settings.cachedBistSymbolCount = symbols.size
            settings.cachedBistSymbolsFetchedAt = System.currentTimeMillis()
            settings.cachedBistSymbolsProviderId = json.optString("source").ifBlank { displayName }
        }
        return symbols
    }

    private suspend fun fetchStock(symbol: String): Stock {
        val requested = normalizeSymbol(symbol)
        val encoded = URLEncoder.encode(requested, "UTF-8")
        val quoteJson = getJson("/v1/bist/quote/$encoded")
        val historyJson = getJson("/v1/bist/history/$encoded?range=1y&interval=1d")
        return parseStockPair(requested, quoteJson, historyJson)
    }

    private fun parseStockPair(requestedRaw: String, quoteJson: JSONObject, historyJson: JSONObject): Stock {
        val requested = normalizeSymbol(requestedRaw)
        val quoteSymbol = quoteJson.optString("symbol").trim().uppercase()
        val historySymbol = historyJson.optString("symbol").trim().uppercase()
        requireMatchingSymbol(requested, quoteSymbol, "quote"); requireMatchingSymbol(requested, historySymbol, "history")
        if (quoteSymbol != historySymbol) throw ProviderException(ProviderFailureCode.BIST_HISTORY_ERROR, "Quote/history sembol kimliği uyuşmuyor: $quoteSymbol/$historySymbol")
        if (quoteJson.optString("market", "BIST").uppercase() != "BIST" || historyJson.optString("market", "BIST").uppercase() != "BIST") throw ProviderException(ProviderFailureCode.BIST_HISTORY_ERROR, "Piyasa kimliği BIST ile eşleşmiyor.")
        val quotePrice=quoteJson.optDouble("price",Double.NaN); val exchangeTimestamp=quoteJson.optLong("exchangeTimestamp",0L)
        val delaySeconds=if(quoteJson.has("delaySeconds")&&!quoteJson.isNull("delaySeconds")) quoteJson.optInt("delaySeconds") else null
        val realtime=quoteJson.optBoolean("realtime",false); val currentSession=historyJson.optBoolean("currentSessionIncluded",quoteJson.optBoolean("currentSessionIncluded",false))
        if(!quotePrice.isFinite()||quotePrice<=0.0||exchangeTimestamp<=0L) throw ProviderException(ProviderFailureCode.BIST_QUOTE_ERROR,"$requested quote verisi geçersiz.")
        val candles=parseCandlesStrict(historyJson.optJSONArray("candles")?:JSONArray(),minimum=RealTimeIntegrityPolicy.MIN_HISTORY_BARS)
        val lastBarTime=historyJson.optLong("lastBarTime",candles.last().timestamp)
        if(lastBarTime!=candles.last().timestamp) throw ProviderException(ProviderFailureCode.BIST_HISTORY_ERROR,"History lastBarTime son mumla eşleşmiyor.")
        val interval=historyJson.optString("interval","1d"); val timezone=historyJson.optString("exchangeTimezone").ifBlank{null}?:throw ProviderException(ProviderFailureCode.BIST_HISTORY_ERROR,"History exchangeTimezone alanı eksik.")
        val previousClose=quoteJson.optDouble("previousClose",Double.NaN).takeIf{it.isFinite()&&it>0.0}?:historyJson.optDouble("previousClose",Double.NaN).takeIf{it.isFinite()&&it>0.0}
        val stock=Stock(symbol=requested,companyName=historyJson.optString("name").takeIf{it.isNotBlank()},candles=candles,source=quoteJson.optString("source").ifBlank{displayName},dataTimestamp=exchangeTimestamp,isRealtime=realtime,delaySeconds=delaySeconds,currentSessionIncluded=currentSession,receivedAt=System.currentTimeMillis(),receivedElapsedRealtime=SystemClock.elapsedRealtime(),quotePrice=quotePrice,currency=quoteJson.optString("currency").takeIf{it.isNotBlank()},market="BIST",historySymbol=historySymbol,interval=interval,exchangeTimezone=timezone,sessionId=historyJson.optString("sessionId").takeIf{it.isNotBlank()},lastBarTime=lastBarTime,lastBarClosed=if(historyJson.has("lastBarClosed"))historyJson.optBoolean("lastBarClosed")else null,previousClose=previousClose,bid=quoteJson.optDouble("bid",Double.NaN).takeIf{it.isFinite()&&it>0.0},ask=quoteJson.optDouble("ask",Double.NaN).takeIf{it.isFinite()&&it>0.0})
        val verdict=RealTimeIntegrityPolicy.validate(stock); if(!verdict.accepted) throw ProviderException(ProviderFailureCode.BIST_HISTORY_ERROR,verdict.reason)
        return stock
    }

    private fun parseCandlesStrict(candlesArray: JSONArray, minimum: Int): List<Candle> {
        val candles = ArrayList<Candle>(candlesArray.length())
        for (i in 0 until candlesArray.length()) {
            val x = candlesArray.optJSONObject(i) ?: throw ProviderException(ProviderFailureCode.BIST_HISTORY_ERROR, "OHLCV[$i] nesne değil.")
            val c = Candle(
                timestamp = x.optLong("timestamp", 0L),
                open = x.optDouble("open", Double.NaN),
                high = x.optDouble("high", Double.NaN),
                low = x.optDouble("low", Double.NaN),
                close = x.optDouble("close", Double.NaN),
                volume = x.optDouble("volume", Double.NaN)
            )
            candles += c
        }
        val sorted = candles.sortedBy { it.timestamp }
        RealTimeIntegrityPolicy.validateCandles(sorted)?.let { throw ProviderException(ProviderFailureCode.BIST_HISTORY_ERROR, it) }
        if (sorted.size < minimum) throw ProviderException(ProviderFailureCode.EMPTY_DATA, "En az $minimum benzersiz ve geçerli OHLCV mumu gerekli; ${sorted.size} alındı.")
        return sorted
    }

    private fun normalizeSymbol(symbol: String): String {
        val s = symbol.trim().uppercase()
        if (!s.matches(Regex("[A-Z0-9_]{3,12}"))) throw ProviderException(ProviderFailureCode.EMPTY_DATA, "Geçersiz BIST sembolü: $symbol")
        return s
    }

    private fun requireMatchingSymbol(requested: String, actualRaw: String, source: String) {
        val actual = actualRaw.trim().uppercase()
        if (actual.isBlank() || actual != requested) throw ProviderException(ProviderFailureCode.BIST_HISTORY_ERROR, "$source sembolü istekle eşleşmiyor: requested=$requested actual=${actual.ifBlank { "<empty>" }}")
    }

    private fun ensureConfigured() {
        if (!settings.baseUrl.startsWith("https://")) throw ProviderException(ProviderFailureCode.BACKEND_URL_MISSING, "Production backend yapılandırılmamış.")
        if (settings.apiKey.isBlank()) throw ProviderException(ProviderFailureCode.API_KEY_MISSING, "Production backend API anahtarı yapılandırılmamış.")
    }

    private suspend fun getJson(path: String): JSONObject {
        val base = settings.baseUrl.trim().removeSuffix("/")
        if (!base.startsWith("https://")) throw ProviderException(ProviderFailureCode.INVALID_HTTPS, "Yalnız HTTPS Production backend kullanılabilir.")
        val req = Request.Builder().url(base + path).get().header("Accept", "application/json")
            .header("Authorization", "Bearer ${settings.apiKey}").build()
        val body = executeCancellable(client.newCall(req))
        return try { JSONObject(body) } catch (t: Throwable) { throw ProviderException(ProviderFailureCode.EMPTY_DATA, "Production backend geçersiz JSON döndürdü.", t) }
    }

    private suspend fun executeCancellable(call: Call): String = suspendCancellableCoroutine { cont ->
        cont.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (!cont.isActive) return
                val ex = when (e) {
                    is SocketTimeoutException -> ProviderException(ProviderFailureCode.NETWORK_TIMEOUT, "Backend isteği zaman aşımına uğradı.", e)
                    is UnknownHostException -> ProviderException(ProviderFailureCode.DNS_ERROR, "Backend alan adı çözümlenemedi.", e)
                    is SSLException -> ProviderException(ProviderFailureCode.TLS_ERROR, "TLS bağlantısı kurulamadı.", e)
                    else -> ProviderException(ProviderFailureCode.NETWORK_ERROR, "Backend ağ isteği başarısız: ${e.message ?: e.javaClass.simpleName}", e)
                }
                cont.resumeWithException(ex)
            }
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!cont.isActive) return
                    val code = it.code
                    val text = it.body?.string().orEmpty()
                    val error = when {
                        code == 401 || code == 403 -> ProviderException(ProviderFailureCode.AUTH_ERROR, "Production backend kimlik doğrulaması başarısız (HTTP $code).")
                        code == 404 || code == 422 -> ProviderException(ProviderFailureCode.EMPTY_DATA, "İstenen piyasa verisi bulunamadı (HTTP $code).")
                        code == 429 -> ProviderException(ProviderFailureCode.RATE_LIMIT, "Production backend istek sınırı aşıldı (HTTP 429). Kısa süre sonra yeniden deneyin.")
                        code >= 500 -> ProviderException(ProviderFailureCode.SERVER_ERROR, "Production backend sunucu hatası (HTTP $code).")
                        code !in 200..299 -> ProviderException(ProviderFailureCode.SERVER_ERROR, "Production backend HTTP $code döndürdü.")
                        text.isBlank() -> ProviderException(ProviderFailureCode.EMPTY_DATA, "Production backend boş yanıt döndürdü.")
                        else -> null
                    }
                    if (error != null) cont.resumeWithException(error) else cont.resume(text)
                }
            }
        })
    }

    private fun String?.ifNullOrBlank(fallback: String): String = if (this.isNullOrBlank()) fallback else this

    companion object {
        private const val TAG = "BIST_SCAN"
        private const val BATCH_SIZE = 20
        private const val BATCH_TIMEOUT_MS = 25_000L
        private val SYSTEMIC_FAILURES = setOf(
            ProviderFailureCode.AUTH_ERROR, ProviderFailureCode.TLS_ERROR, ProviderFailureCode.DNS_ERROR,
            ProviderFailureCode.NETWORK_TIMEOUT, ProviderFailureCode.RATE_LIMIT, ProviderFailureCode.SERVER_ERROR,
            ProviderFailureCode.BACKEND_URL_MISSING, ProviderFailureCode.API_KEY_MISSING, ProviderFailureCode.INVALID_HTTPS
        )
    }
}
