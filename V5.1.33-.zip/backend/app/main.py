from __future__ import annotations

import math
import os
import re
import time
import asyncio
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any
from urllib.parse import quote

from fastapi import FastAPI, Header, HTTPException, Query, WebSocket, WebSocketDisconnect
from pydantic import BaseModel

from .provider_adapter import LicensedUpstreamProvider, ProviderError

UPSTREAM = LicensedUpstreamProvider()

@asynccontextmanager
async def lifespan(app: FastAPI):
    yield
    await UPSTREAM.close()

app = FastAPI(title="BorsaTakip Backend", version="1.6.0", lifespan=lifespan)
API_KEY = os.getenv("BORSA_BACKEND_API_KEY", "").strip()
API_KEYS = {x.strip() for x in os.getenv("BORSA_BACKEND_API_KEYS", "").split(",") if x.strip()}
if API_KEY: API_KEYS.add(API_KEY)
RATE_LIMIT_PER_MINUTE = max(10, min(int(os.getenv("BORSA_RATE_LIMIT_PER_MINUTE", "120")), 5000))
_rate_windows: dict[str, deque[float]] = defaultdict(deque)
MAX_REALTIME_AGE_MS = int(os.getenv("BORSA_MAX_REALTIME_AGE_MS", "60000"))
MAX_DECLARED_DELAY_SECONDS = int(os.getenv("BORSA_MAX_DECLARED_DELAY_SECONDS", "5"))
LIVE_MAX_SYMBOLS = max(1, min(int(os.getenv("BORSA_LIVE_MAX_SYMBOLS", "50")), 200))
LIVE_MAX_TICKS_PER_MINUTE = max(60, min(int(os.getenv("BORSA_LIVE_MAX_TICKS_PER_MINUTE", "3000")), 20000))


class Health(BaseModel):
    ok: bool
    provider: str
    message: str
    timestamp: int
    strictRealtime: bool = True
    maxRealtimeAgeMs: int
    maxDeclaredDelaySeconds: int
    configurationReady: bool
    authenticationConfigured: bool
    viopConfigured: bool




class ViopHealth(BaseModel):
    ok: bool
    provider: str
    connectionStatus: str
    configured: bool
    lastUpdate: int | None = None
    dataAgeMs: int | None = None
    latencyMs: int | None = None
    errorCode: str | None = None
    message: str

class SymbolsResponse(BaseModel):
    items: list[str]
    source: str
    dataTimestamp: int


class QuoteResponse(BaseModel):
    symbol: str
    market: str = "BIST"
    price: float
    bid: float | None = None
    ask: float | None = None
    dailyChangePct: float | None = None
    volume: float | None = None
    openInterest: int | None = None
    currency: str | None = None
    exchangeTimestamp: int
    receivedAt: int
    source: str
    providerId: str
    realtime: bool
    currentSessionIncluded: bool
    delaySeconds: int
    dataMode: str = "REALTIME"
    previousClose: float | None = None


class Candle(BaseModel):
    timestamp: int
    open: float
    high: float
    low: float
    close: float
    volume: float


class HistoryResponse(BaseModel):
    symbol: str
    market: str = "BIST"
    name: str | None = None
    candles: list[Candle]
    source: str
    dataTimestamp: int
    candleCount: int
    dataMode: str = "HISTORICAL"
    interval: str = "1d"
    exchangeTimezone: str
    sessionId: str | None = None
    lastBarTime: int
    lastBarClosed: bool | None = None
    currentSessionIncluded: bool = False
    previousClose: float | None = None


class PreflightCheck(BaseModel):
    ok: bool
    code: str
    message: str


class PreflightResponse(BaseModel):
    ok: bool
    provider: str
    symbolCount: int = 0
    sampleSymbol: str | None = None
    backendConfig: PreflightCheck
    authentication: PreflightCheck
    symbols: PreflightCheck
    quote: PreflightCheck
    history: PreflightCheck


class ViopContract(BaseModel):
    symbol: str
    underlying: str
    expiry: str
    contractType: str = "Vadeli İşlem"
    lastPrice: float | None = None
    bid: float | None = None
    ask: float | None = None
    dailyChangePct: float | None = None
    tickSize: float
    multiplier: float
    openInterest: int | None = None
    volume: float | None = None
    liquidity: str | None = None
    rollover: str | None = None
    currency: str | None = None
    source: str
    dataTimestamp: int
    realtime: bool
    delaySeconds: int
    currentSessionIncluded: bool
    lastTradingAt: int | None = None
    expiryAt: int | None = None
    exchangeTimezone: str | None = None
    settlementType: str | None = None


class ViopResponse(BaseModel):
    items: list[ViopContract]
    source: str
    dataTimestamp: int


class NewsItemResponse(BaseModel):
    id: str
    symbol: str | None = None
    category: str
    title: str
    summary: str | None = None
    source: str
    publishedAt: int
    url: str | None = None
    verified: bool = False


class NewsResponse(BaseModel):
    items: list[NewsItemResponse]
    source: str
    dataTimestamp: int


def _normalize_news(payload: Any, requested_symbol: str | None = None) -> NewsResponse:
    raw = payload.get("items") if isinstance(payload, dict) else payload
    if not isinstance(raw, list):
        raise HTTPException(status_code=502, detail={"code":"NEWS_ERROR","message":"Upstream news response must be an array or contain items"})
    items: list[NewsItemResponse] = []
    for idx, row in enumerate(raw):
        if not isinstance(row, dict):
            continue
        title = str(row.get("title") or "").strip()
        source = str(row.get("source") or UPSTREAM.name).strip()
        try: published = int(row.get("publishedAt") or row.get("timestamp") or 0)
        except (TypeError, ValueError): published = 0
        if not title or not source or published <= 0:
            continue
        symbol = str(row.get("symbol") or requested_symbol or "").strip().upper() or None
        category = str(row.get("category") or "GENEL").strip().upper()
        url = str(row.get("url") or "").strip() or None
        if url is not None and not url.startswith("https://"):
            url = None
        summary = str(row.get("summary") or "").strip() or None
        item_id = str(row.get("id") or f"{source}:{published}:{idx}")
        verified = row.get("verified") is True
        items.append(NewsItemResponse(id=item_id, symbol=symbol, category=category, title=title, summary=summary, source=source, publishedAt=published, url=url, verified=verified))
    items.sort(key=lambda x: x.publishedAt, reverse=True)
    if not items:
        raise HTTPException(status_code=502, detail={"code":"EMPTY_DATA","message":"Upstream returned no valid news items"})
    return NewsResponse(items=items, source=UPSTREAM.name, dataTimestamp=int(time.time()*1000))


def _provider_http(exc: ProviderError) -> HTTPException:
    return HTTPException(status_code=exc.status_code, detail={"code": exc.code.value, "message": exc.message})


def _auth_configured() -> bool:
    return bool(API_KEYS and "CHANGE_ME_IN_DEPLOYMENT" not in API_KEYS)


def _require_client_auth(authorization: str | None) -> None:
    if not _auth_configured():
        raise HTTPException(status_code=503, detail={"code": "AUTH_NOT_CONFIGURED", "message": "Production client authentication is not configured"})
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail={"code": "AUTH_ERROR", "message": "Unauthorized"})
    token = authorization[7:]
    if token not in API_KEYS:
        raise HTTPException(status_code=401, detail={"code": "AUTH_ERROR", "message": "Unauthorized"})
    now = time.monotonic(); q = _rate_windows[token]
    while q and q[0] < now - 60.0: q.popleft()
    if len(q) >= RATE_LIMIT_PER_MINUTE:
        raise HTTPException(status_code=429, detail={"code":"RATE_LIMIT","message":"Client request quota exceeded"})
    q.append(now)


def _normalize_symbol(symbol: str) -> str:
    normalized = symbol.strip().upper()
    if not (3 <= len(normalized) <= 32 and normalized.replace("_", "").replace("-", "").isalnum()):
        raise HTTPException(status_code=400, detail={"code": "INVALID_SYMBOL", "message": "Invalid symbol"})
    return normalized


def _normalize_symbols(payload: Any) -> list[str]:
    raw = payload.get("items") if isinstance(payload, dict) else payload
    if not isinstance(raw, list):
        raise HTTPException(status_code=502, detail={"code": "INVALID_DATA", "message": "Upstream symbol response must contain an items array"})
    out: list[str] = []
    seen: set[str] = set()
    for value in raw:
        symbol = str(value).strip().upper()
        if 3 <= len(symbol) <= 12 and symbol.replace("_", "").isalnum() and symbol not in seen:
            seen.add(symbol); out.append(symbol)
    if not out:
        raise HTTPException(status_code=502, detail={"code": "EMPTY_DATA", "message": "Upstream returned no valid BIST symbols"})
    return out


def _require_realtime_metadata(payload: dict[str, Any]) -> tuple[int, int]:
    if payload.get("realtime") is not True:
        raise HTTPException(status_code=409, detail={"code": "NOT_REALTIME", "message": "Upstream did not certify data as real-time"})
    if payload.get("currentSessionIncluded") is not True:
        raise HTTPException(status_code=409, detail={"code": "SESSION_MISSING", "message": "Current trading session is not included"})
    try:
        delay_seconds = int(payload["delaySeconds"])
        exchange_ts = int(payload.get("exchangeTimestamp", payload.get("dataTimestamp")))
    except (KeyError, TypeError, ValueError) as exc:
        raise HTTPException(status_code=409, detail={"code": "PROVENANCE_INCOMPLETE", "message": "Real-time provenance metadata is incomplete"}) from exc
    if delay_seconds < 0 or delay_seconds > MAX_DECLARED_DELAY_SECONDS:
        raise HTTPException(status_code=409, detail={"code": "DELAY_TOO_HIGH", "message": f"Declared provider delay is {delay_seconds}s; strict limit is {MAX_DECLARED_DELAY_SECONDS}s"})
    now = int(time.time() * 1000)
    age = now - exchange_ts
    if exchange_ts <= 0 or age > MAX_REALTIME_AGE_MS:
        raise HTTPException(status_code=409, detail={"code": "STALE_DATA", "message": f"Market data is stale; age={max(age, 0)}ms strict_limit={MAX_REALTIME_AGE_MS}ms"})
    if age < -15_000:
        raise HTTPException(status_code=409, detail={"code": "FUTURE_TIMESTAMP", "message": "Market timestamp is ahead of server clock"})
    return delay_seconds, exchange_ts


def _finite_optional(value: Any, *, positive: bool = False, nonnegative: bool = False) -> float | None:
    if value is None: return None
    try: number = float(value)
    except (TypeError, ValueError): return None
    if not math.isfinite(number): return None
    if positive and number <= 0: return None
    if nonnegative and number < 0: return None
    return number


def _normalize_quote(payload: Any, requested_symbol: str, expected_market: str = "BIST") -> QuoteResponse:
    if not isinstance(payload, dict):
        raise HTTPException(status_code=502, detail={"code": "INVALID_DATA", "message": "Upstream quote response must be an object"})
    delay_seconds, exchange_ts = _require_realtime_metadata(payload)
    price = _finite_optional(payload.get("price", payload.get("last")), positive=True)
    if price is None:
        raise HTTPException(status_code=502, detail={"code": "QUOTE_ERROR", "message": "Quote price is missing or invalid"})
    open_interest = None
    if payload.get("openInterest") is not None:
        try:
            oi = int(payload["openInterest"])
            open_interest = oi if oi >= 0 else None
        except (TypeError, ValueError):
            pass
    actual_symbol = str(payload.get("symbol") or "").strip().upper()
    if not actual_symbol or actual_symbol != requested_symbol:
        raise HTTPException(status_code=409, detail={"code":"SYMBOL_MISMATCH","message":f"Quote symbol mismatch: requested={requested_symbol} actual={actual_symbol or '<empty>'}"})
    market = str(payload.get("market") or "BIST").strip().upper()
    if market != expected_market:
        raise HTTPException(status_code=409, detail={"code":"MARKET_MISMATCH","message":f"Unexpected market: expected={expected_market} actual={market}"})
    return QuoteResponse(
        symbol=actual_symbol, market=market, price=price,
        bid=_finite_optional(payload.get("bid"), nonnegative=True), ask=_finite_optional(payload.get("ask"), nonnegative=True),
        dailyChangePct=_finite_optional(payload.get("dailyChangePct", payload.get("changePct"))),
        volume=_finite_optional(payload.get("volume"), nonnegative=True), openInterest=open_interest,
        currency=str(payload.get("currency")).strip() if payload.get("currency") else None,
        exchangeTimestamp=exchange_ts, receivedAt=int(time.time() * 1000),
        source=str(payload.get("source") or UPSTREAM.name).strip() or UPSTREAM.name,
        providerId=str(payload.get("providerId") or UPSTREAM.name).strip() or UPSTREAM.name,
        realtime=True, currentSessionIncluded=True, delaySeconds=delay_seconds, dataMode="REALTIME",
        previousClose=_finite_optional(payload.get("previousClose"), positive=True)
    )


def _strict_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool): return value
    if value is None: return default
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "1", "yes", "y", "on"}: return True
        if normalized in {"false", "0", "no", "n", "off", ""}: return False
    if isinstance(value, (int, float)): return bool(value)
    return default

def _normalize_candles(payload: Any, requested_symbol: str, min_candles: int = 220, interval: str = "1d", market: str = "BIST") -> HistoryResponse:
    if not isinstance(payload, dict):
        raise HTTPException(status_code=502, detail={"code": "INVALID_DATA", "message": "Upstream history response must be an object"})
    actual_symbol = str(payload.get("symbol") or "").strip().upper()
    if not actual_symbol or actual_symbol != requested_symbol:
        raise HTTPException(status_code=409, detail={"code":"SYMBOL_MISMATCH","message":f"History symbol mismatch: requested={requested_symbol} actual={actual_symbol or '<empty>'}"})
    actual_market = str(payload.get("market") or market).strip().upper()
    if actual_market != market:
        raise HTTPException(status_code=409, detail={"code":"MARKET_MISMATCH","message":f"History market mismatch: expected={market} actual={actual_market}"})
    rows = payload.get("candles")
    if not isinstance(rows, list):
        raise HTTPException(status_code=502, detail={"code": "HISTORY_ERROR", "message": "Upstream history response must contain candles"})
    candles: list[Candle] = []
    seen: set[int] = set()
    now = int(time.time()*1000)
    previous_ts = -1
    for idx, row in enumerate(rows):
        if not isinstance(row, dict):
            raise HTTPException(status_code=502, detail={"code":"HISTORY_ERROR","message":f"Candle {idx} is not an object"})
        try:
            c = Candle(timestamp=int(row["timestamp"]), open=float(row["open"]), high=float(row["high"]), low=float(row["low"]), close=float(row["close"]), volume=float(row["volume"]))
        except (KeyError, TypeError, ValueError) as exc:
            raise HTTPException(status_code=502, detail={"code":"HISTORY_ERROR","message":f"Candle {idx} is malformed"}) from exc
        vals=[c.open,c.high,c.low,c.close,c.volume]
        if not all(math.isfinite(v) for v in vals) or c.timestamp <= 0:
            raise HTTPException(status_code=502, detail={"code":"HISTORY_ERROR","message":f"Candle {idx} has non-finite/invalid values"})
        if c.timestamp > now + 15_000:
            raise HTTPException(status_code=409, detail={"code":"FUTURE_CANDLE","message":f"Candle {idx} is future-dated"})
        if c.timestamp in seen or (previous_ts >= 0 and c.timestamp <= previous_ts):
            raise HTTPException(status_code=409, detail={"code":"DUPLICATE_OR_UNSORTED_CANDLE","message":f"Candle {idx} timestamp is duplicate or unsorted"})
        if min(c.open,c.close) < c.low or max(c.open,c.close) > c.high or min(c.open,c.high,c.low,c.close) <= 0 or c.volume < 0:
            raise HTTPException(status_code=409, detail={"code":"INVALID_OHLC","message":f"Candle {idx} violates OHLCV bounds"})
        seen.add(c.timestamp); previous_ts=c.timestamp; candles.append(c)
    if len(candles) < min_candles:
        raise HTTPException(status_code=422, detail={"code": "INSUFFICIENT_HISTORY", "message": f"Insufficient unique OHLCV history: {len(candles)} candles; minimum {min_candles}"})
    declared_interval = str(payload.get("interval") or interval).strip()
    if declared_interval != interval:
        raise HTTPException(status_code=409, detail={"code":"INTERVAL_MISMATCH","message":f"History interval mismatch: requested={interval} actual={declared_interval}"})
    timezone_name = str(payload.get("exchangeTimezone") or "").strip()
    if not timezone_name:
        raise HTTPException(status_code=409, detail={"code":"PROVENANCE_INCOMPLETE","message":"exchangeTimezone is required for history"})
    last_bar = candles[-1]
    raw_declared_last = payload.get("lastBarTime")
    if raw_declared_last in (None, ""):
        declared_last = last_bar.timestamp
    else:
        try:
            declared_last = int(raw_declared_last)
        except (TypeError, ValueError) as exc:
            raise HTTPException(status_code=409, detail={"code":"LAST_BAR_INVALID","message":"lastBarTime must be an integer"}) from exc
    if declared_last != last_bar.timestamp:
        raise HTTPException(status_code=409, detail={"code":"LAST_BAR_MISMATCH","message":"lastBarTime does not match last candle"})
    return HistoryResponse(
        symbol=actual_symbol, market=actual_market, name=str(payload.get("name")).strip() if payload.get("name") else None, candles=candles,
        source=str(payload.get("source") or UPSTREAM.name).strip() or UPSTREAM.name, dataTimestamp=int(payload.get("dataTimestamp") or last_bar.timestamp),
        candleCount=len(candles), dataMode=str(payload.get("dataMode") or "HISTORICAL").upper(), interval=str(payload.get("interval") or interval),
        exchangeTimezone=timezone_name, sessionId=str(payload.get("sessionId") or "").strip() or None, lastBarTime=last_bar.timestamp,
        lastBarClosed=payload.get("lastBarClosed") if isinstance(payload.get("lastBarClosed"), bool) else None,
        currentSessionIncluded=_strict_bool(payload.get("currentSessionIncluded"), False), previousClose=_finite_optional(payload.get("previousClose"), positive=True)
    )


def _expiry_is_current_or_future(expiry: str) -> bool:
    if not re.fullmatch(r"\d{4}-\d{2}", expiry): return False
    try:
        year, month = [int(x) for x in expiry.split("-")]
        now = datetime.now(timezone.utc)
        return 1 <= month <= 12 and (year, month) >= (now.year, now.month)
    except ValueError: return False


def _normalize_viop_row(row: dict[str, Any]) -> ViopContract | None:
    symbol = str(row.get("symbol") or "").strip().upper(); underlying = str(row.get("underlying") or "").strip().upper(); expiry = str(row.get("expiry") or "").strip()
    if not symbol or not underlying or not _expiry_is_current_or_future(expiry): return None
    tick = _finite_optional(row.get("tickSize"), positive=True); mult = _finite_optional(row.get("multiplier"), positive=True)
    if tick is None or mult is None: return None
    try: delay = int(row["delaySeconds"]); ts = int(row["dataTimestamp"])
    except (KeyError, TypeError, ValueError): return None
    if row.get("realtime") is not True or row.get("currentSessionIncluded") is not True: return None
    now = int(time.time() * 1000); age = now - ts
    if delay < 0 or delay > MAX_DECLARED_DELAY_SECONDS or ts <= 0 or age > MAX_REALTIME_AGE_MS or age < -15_000: return None
    oi = None
    if row.get("openInterest") is not None:
        try:
            v = int(row["openInterest"]); oi = v if v >= 0 else None
        except (TypeError, ValueError): pass
    last_trading_at = int(row.get("lastTradingAt") or 0) or None
    expiry_at = int(row.get("expiryAt") or 0) or None
    if last_trading_at is None: return None
    return ViopContract(symbol=symbol, underlying=underlying, expiry=expiry, contractType=str(row.get("contractType") or "Vadeli İşlem"), lastPrice=_finite_optional(row.get("lastPrice",row.get("last")), positive=True), bid=_finite_optional(row.get("bid"),nonnegative=True), ask=_finite_optional(row.get("ask"),nonnegative=True), dailyChangePct=_finite_optional(row.get("dailyChangePct",row.get("changePct"))), tickSize=tick, multiplier=mult, openInterest=oi, volume=_finite_optional(row.get("volume"),nonnegative=True), liquidity=str(row.get("liquidity")).strip() if row.get("liquidity") else None, rollover=str(row.get("rollover")).strip() if row.get("rollover") else None, currency=str(row.get("currency")).strip() if row.get("currency") else None, source=str(row.get("source") or UPSTREAM.name), dataTimestamp=ts, realtime=True, delaySeconds=delay, currentSessionIncluded=True, lastTradingAt=last_trading_at, expiryAt=expiry_at, exchangeTimezone=str(row.get("exchangeTimezone") or "").strip() or None, settlementType=str(row.get("settlementType") or "").strip() or None)


async def _symbols_impl() -> SymbolsResponse:
    try: payload = await UPSTREAM.get_json(UPSTREAM.symbols_url)
    except ProviderError as exc: raise _provider_http(exc) from exc
    items = _normalize_symbols(payload)
    return SymbolsResponse(items=items, source=UPSTREAM.name, dataTimestamp=int(time.time()*1000))


async def _quote_impl(symbol: str) -> QuoteResponse:
    normalized = _normalize_symbol(symbol)
    if "{symbol}" not in UPSTREAM.quote_url_template: raise HTTPException(status_code=503, detail={"code":"NOT_CONFIGURED","message":"BORSA_QUOTE_URL_TEMPLATE must contain {symbol}"})
    try: payload = await UPSTREAM.get_json(UPSTREAM.quote_url_template.replace("{symbol}", quote(normalized,safe="")))
    except ProviderError as exc: raise _provider_http(exc) from exc
    return _normalize_quote(payload, normalized)


async def _history_impl(symbol: str, range_value: str = "1y") -> HistoryResponse:
    normalized = _normalize_symbol(symbol)
    if "{symbol}" not in UPSTREAM.history_url_template: raise HTTPException(status_code=503, detail={"code":"NOT_CONFIGURED","message":"BORSA_HISTORY_URL_TEMPLATE must contain {symbol}"})
    if range_value not in {"1y", "max"}:
        raise HTTPException(status_code=400, detail={"code":"UNSUPPORTED_RANGE","message":"range must be 1y or max"})
    url = (UPSTREAM.history_url_template
        .replace("{symbol}", quote(normalized,safe=""))
        .replace("{range}", range_value)
        .replace("{interval}", "1d"))
    try: payload = await UPSTREAM.get_json(url)
    except ProviderError as exc: raise _provider_http(exc) from exc
    return _normalize_candles(payload, normalized, min_candles=1 if range_value == "max" else 220, interval="1d", market="BIST")


async def _history_window_impl(symbol: str, from_ms: int, to_ms: int, interval: str) -> HistoryResponse:
    normalized = _normalize_symbol(symbol)
    template = UPSTREAM.intraday_history_url_template
    required = ("{symbol}", "{from}", "{to}", "{interval}")
    if not template or any(token not in template for token in required):
        raise HTTPException(status_code=503, detail={"code":"NOT_CONFIGURED","message":"BORSA_INTRADAY_HISTORY_URL_TEMPLATE must contain {symbol}, {from}, {to}, {interval}"})
    if from_ms <= 0 or to_ms <= from_ms:
        raise HTTPException(status_code=400, detail={"code":"INVALID_RANGE","message":"from/to range is invalid"})
    if interval not in {"1m","5m","15m","30m","60m"}:
        raise HTTPException(status_code=400, detail={"code":"UNSUPPORTED_INTERVAL","message":"interval must be one of 1m,5m,15m,30m,60m"})
    url = (template
        .replace("{symbol}", quote(normalized, safe=""))
        .replace("{from}", str(from_ms))
        .replace("{to}", str(to_ms))
        .replace("{interval}", interval))
    try:
        payload = await UPSTREAM.get_json(url)
    except ProviderError as exc:
        raise _provider_http(exc) from exc
    history = _normalize_candles(payload, normalized, min_candles=1, interval=interval, market="BIST")
    candles = [c for c in history.candles if from_ms <= c.timestamp <= to_ms]
    if not candles:
        raise HTTPException(status_code=422, detail={"code":"EMPTY_DATA","message":"No candle falls inside the requested window"})
    return HistoryResponse(symbol=history.symbol, market=history.market, name=history.name, candles=candles, source=history.source, dataTimestamp=max(c.timestamp for c in candles), candleCount=len(candles), dataMode="HISTORICAL", interval=interval, exchangeTimezone=history.exchangeTimezone, sessionId=history.sessionId, lastBarTime=candles[-1].timestamp, lastBarClosed=history.lastBarClosed, currentSessionIncluded=history.currentSessionIncluded, previousClose=history.previousClose)


async def _viop_quote_impl(symbol: str) -> QuoteResponse:
    normalized = _normalize_symbol(symbol)
    if "{symbol}" not in UPSTREAM.viop_quote_url_template: raise HTTPException(status_code=503, detail={"code":"NOT_CONFIGURED","message":"BORSA_VIOP_QUOTE_URL_TEMPLATE must contain {symbol}"})
    try: payload = await UPSTREAM.get_json(UPSTREAM.viop_quote_url_template.replace("{symbol}", quote(normalized,safe="")))
    except ProviderError as exc: raise _provider_http(exc) from exc
    return _normalize_quote(payload, normalized, expected_market="VIOP")


async def _viop_history_impl(symbol: str) -> HistoryResponse:
    normalized = _normalize_symbol(symbol)
    if "{symbol}" not in UPSTREAM.viop_history_url_template: raise HTTPException(status_code=503, detail={"code":"NOT_CONFIGURED","message":"BORSA_VIOP_HISTORY_URL_TEMPLATE must contain {symbol}"})
    try: payload = await UPSTREAM.get_json(UPSTREAM.viop_history_url_template.replace("{symbol}", quote(normalized,safe="")))
    except ProviderError as exc: raise _provider_http(exc) from exc
    return _normalize_candles(payload, normalized, min_candles=1, interval="1d", market="VIOP")


@app.get("/v1/health", response_model=Health)
async def health() -> Health:
    configured = UPSTREAM.configuration_ready(); auth_ready = _auth_configured()
    return Health(ok=True, provider=UPSTREAM.name if configured else "unconfigured", message="Backend process is healthy" if configured and auth_ready else "Backend process is healthy but production configuration is incomplete", timestamp=int(time.time()*1000), maxRealtimeAgeMs=MAX_REALTIME_AGE_MS, maxDeclaredDelaySeconds=MAX_DECLARED_DELAY_SECONDS, configurationReady=configured, authenticationConfigured=auth_ready, viopConfigured=UPSTREAM.viop_configuration_ready())


@app.get("/v1/preflight", response_model=PreflightResponse)
async def preflight(authorization: str | None = Header(default=None)) -> PreflightResponse:
    _require_client_auth(authorization)
    config_ok = UPSTREAM.configuration_ready(); auth_ok = True
    bc = PreflightCheck(ok=config_ok, code="OK" if config_ok else "PRODUCTION_BACKEND_NOT_CONFIGURED", message="Licensed symbols/quote/history endpoints configured" if config_ok else "Licensed symbols/quote/history endpoints are incomplete")
    ac = PreflightCheck(ok=auth_ok, code="OK" if auth_ok else ("AUTH_NOT_CONFIGURED" if not _auth_configured() else "AUTH_ERROR"), message="Client authentication verified" if auth_ok else "Client authentication failed or is not configured")
    blocked = PreflightCheck(ok=False, code="BLOCKED", message="Blocked by configuration/authentication")
    if not config_ok or not auth_ok: return PreflightResponse(ok=False, provider=UPSTREAM.name, backendConfig=bc, authentication=ac, symbols=blocked, quote=blocked, history=blocked)
    try: syms = await _symbols_impl(); sc = PreflightCheck(ok=True,code="OK",message=f"{len(syms.items)} symbols received"); sample=syms.items[0]
    except HTTPException as exc: return PreflightResponse(ok=False,provider=UPSTREAM.name,backendConfig=bc,authentication=ac,symbols=PreflightCheck(ok=False,code="SYMBOLS_ERROR",message=str(exc.detail)),quote=blocked,history=blocked)
    try: await _quote_impl(sample); qc=PreflightCheck(ok=True,code="OK",message=f"Live quote verified for {sample}")
    except HTTPException as exc: return PreflightResponse(ok=False,provider=UPSTREAM.name,symbolCount=len(syms.items),sampleSymbol=sample,backendConfig=bc,authentication=ac,symbols=sc,quote=PreflightCheck(ok=False,code="QUOTE_ERROR",message=str(exc.detail)),history=blocked)
    try: hist=await _history_impl(sample); hc=PreflightCheck(ok=True,code="OK",message=f"{hist.candleCount} valid candles received")
    except HTTPException as exc: return PreflightResponse(ok=False,provider=UPSTREAM.name,symbolCount=len(syms.items),sampleSymbol=sample,backendConfig=bc,authentication=ac,symbols=sc,quote=qc,history=PreflightCheck(ok=False,code="HISTORY_ERROR",message=str(exc.detail)))
    return PreflightResponse(ok=True,provider=UPSTREAM.name,symbolCount=len(syms.items),sampleSymbol=sample,backendConfig=bc,authentication=ac,symbols=sc,quote=qc,history=hc)


@app.get("/v1/bist/symbols", response_model=SymbolsResponse)
async def bist_symbols(authorization: str | None = Header(default=None)) -> SymbolsResponse:
    _require_client_auth(authorization); return await _symbols_impl()


@app.get("/v1/bist/quote/{symbol}", response_model=QuoteResponse)
async def bist_quote(symbol: str, authorization: str | None = Header(default=None)) -> QuoteResponse:
    _require_client_auth(authorization); return await _quote_impl(symbol)


@app.get("/v1/bist/history/{symbol}", response_model=HistoryResponse)
async def bist_history(symbol: str, range: str = Query(default="1y"), interval: str = Query(default="1d"), authorization: str | None = Header(default=None)) -> HistoryResponse:
    _require_client_auth(authorization)
    if range not in {"1y", "max"} or interval != "1d":
        raise HTTPException(status_code=400,detail={"code":"UNSUPPORTED_RANGE","message":"range must be 1y or max and interval must be 1d"})
    return await _history_impl(symbol, range)


@app.get("/v1/bist/snapshot-batch")
async def bist_snapshot_batch(symbols: str = Query(...), authorization: str | None = Header(default=None)) -> dict[str, Any]:
    _require_client_auth(authorization)
    requested=[]; seen=set()
    for raw in symbols.split(","):
        if not str(raw).strip():
            raise HTTPException(status_code=400, detail={"code":"EMPTY_SYMBOL","message":"Batch symbol cannot be empty"})
        sym=_normalize_symbol(raw)
        if sym not in seen:
            seen.add(sym); requested.append(sym)
    if not requested:
        raise HTTPException(status_code=400, detail={"code":"EMPTY_SYMBOLS","message":"At least one BIST symbol is required"})
    if len(requested) > 25:
        raise HTTPException(status_code=400, detail={"code":"TOO_MANY_SYMBOLS","message":"Batch supports at most 25 symbols"})
    async def one(sym: str) -> dict[str, Any]:
        try:
            q,h=await asyncio.gather(_quote_impl(sym), _history_impl(sym))
            if q.symbol != sym or h.symbol != sym:
                raise HTTPException(status_code=409, detail={"code":"SYMBOL_MISMATCH","message":f"Batch item identity mismatch for {sym}"})
            return {"symbol":sym,"quote":q.model_dump(),"history":h.model_dump()}
        except HTTPException as exc:
            detail=exc.detail if isinstance(exc.detail,dict) else {"code":"SYMBOL_ERROR","message":str(exc.detail)}
            return {"symbol":sym,"error":detail}
    try:
        items = await asyncio.wait_for(asyncio.gather(*(one(sym) for sym in requested)), timeout=45.0)
    except asyncio.TimeoutError as exc:
        raise HTTPException(status_code=504, detail={"code":"BATCH_DEADLINE_EXCEEDED","message":"BIST snapshot batch exceeded its total execution deadline"}) from exc
    returned=[str(item.get("symbol") or "").strip().upper() for item in items]
    if len(items)!=len(requested) or len(set(returned))!=len(returned) or set(returned)!=set(requested):
        raise HTTPException(status_code=502, detail={"code":"BATCH_CONTRACT_MISMATCH","message":"Batch response symbols must exactly match the requested unique symbol set"})
    return {"items":items,"count":len(items),"requestedCount":len(requested),"source":UPSTREAM.name,"dataTimestamp":int(time.time()*1000)}




@app.get("/v1/bist/history-window/{symbol}", response_model=HistoryResponse)
async def bist_history_window(symbol: str, from_: int = Query(alias="from"), to: int = Query(...), interval: str = Query(default="1m"), authorization: str | None = Header(default=None)) -> HistoryResponse:
    _require_client_auth(authorization)
    return await _history_window_impl(symbol, from_, to, interval)




@app.get("/v1/viop/health", response_model=ViopHealth)
async def viop_health(authorization: str | None = Header(default=None)) -> ViopHealth:
    _require_client_auth(authorization)
    configured = UPSTREAM.viop_configuration_ready()
    if not configured:
        return ViopHealth(ok=False, provider=UPSTREAM.name, connectionStatus="NOT_CONFIGURED", configured=False, errorCode="VIOP_PROVIDER_NOT_CONFIGURED", message="Licensed VIOP upstream is not fully configured")
    started = time.perf_counter()
    try:
        if not UPSTREAM.viop_url:
            raise HTTPException(status_code=503, detail={"code":"NOT_CONFIGURED","message":"VIOP upstream is not configured"})
        payload = await UPSTREAM.get_json(UPSTREAM.viop_url)
        rows = payload.get("items") if isinstance(payload,dict) else payload
        if not isinstance(rows,list) or not rows:
            return ViopHealth(ok=False, provider=UPSTREAM.name, connectionStatus="ERROR", configured=True, latencyMs=int((time.perf_counter()-started)*1000), errorCode="EMPTY_CONTRACTS", message="VIOP upstream returned no contracts")
        valid = [_normalize_viop_row(r) for r in rows if isinstance(r,dict)]
        valid = [x for x in valid if x is not None]
        if not valid:
            return ViopHealth(ok=False, provider=UPSTREAM.name, connectionStatus="ERROR", configured=True, latencyMs=int((time.perf_counter()-started)*1000), errorCode="INVALID_DATA", message="No VIOP contract passed validation")
        last = max(x.dataTimestamp for x in valid)
        now = int(time.time()*1000)
        return ViopHealth(ok=True, provider=UPSTREAM.name, connectionStatus="ONLINE", configured=True, lastUpdate=last, dataAgeMs=max(0, now-last), latencyMs=int((time.perf_counter()-started)*1000), message=f"{len(valid)} validated VIOP contracts available")
    except ProviderError as exc:
        return ViopHealth(ok=False, provider=UPSTREAM.name, connectionStatus="ERROR", configured=True, latencyMs=int((time.perf_counter()-started)*1000), errorCode=str(exc.code.value), message=str(exc))

@app.get("/v1/viop/contracts", response_model=ViopResponse)
async def viop_contracts(authorization: str | None = Header(default=None)) -> ViopResponse:
    _require_client_auth(authorization)
    if not UPSTREAM.viop_url: raise HTTPException(status_code=503,detail={"code":"NOT_CONFIGURED","message":"VIOP upstream is not configured"})
    try: payload = await UPSTREAM.get_json(UPSTREAM.viop_url)
    except ProviderError as exc: raise _provider_http(exc) from exc
    rows = payload.get("items") if isinstance(payload,dict) else payload
    if not isinstance(rows,list): raise HTTPException(status_code=502,detail={"code":"INVALID_DATA","message":"Upstream VIOP response must contain an items array"})
    items=[_normalize_viop_row(r) for r in rows if isinstance(r,dict)]; valid=[x for x in items if x is not None]
    if not valid: raise HTTPException(status_code=422,detail={"code":"INVALID_DATA","message":"No VIOP contract passed validation"})
    return ViopResponse(items=valid,source=UPSTREAM.name,dataTimestamp=max(x.dataTimestamp for x in valid))


@app.get("/v1/viop/quote/{symbol}", response_model=QuoteResponse)
async def viop_quote(symbol: str, authorization: str | None = Header(default=None)) -> QuoteResponse:
    _require_client_auth(authorization)
    return await _viop_quote_impl(symbol)


@app.get("/v1/viop/history/{symbol}", response_model=HistoryResponse)
async def viop_history(symbol: str, range: str = Query(default="1y"), interval: str = Query(default="1d"), authorization: str | None = Header(default=None)) -> HistoryResponse:
    _require_client_auth(authorization)
    if range != "1y" or interval != "1d": raise HTTPException(status_code=400,detail={"code":"UNSUPPORTED_RANGE","message":"Only range=1y&interval=1d is supported"})
    return await _viop_history_impl(symbol)


@app.get("/v1/news", response_model=NewsResponse)
async def news(authorization: str | None = Header(default=None), symbol: str | None = Query(default=None), category: str = Query(default="ALL")) -> NewsResponse:
    _require_client_auth(authorization)
    if not UPSTREAM.news_configuration_ready():
        raise HTTPException(status_code=503, detail={"code":"NEWS_NOT_CONFIGURED","message":"Licensed news upstream is not configured"})
    normalized_symbol = _normalize_symbol(symbol) if symbol else None
    url = UPSTREAM.news_url_template
    url = url.replace("{symbol}", quote(normalized_symbol or "", safe="")).replace("{category}", quote(category.upper(), safe=""))
    try:
        payload = await UPSTREAM.get_json(url)
    except ProviderError as exc:
        raise _provider_http(exc) from exc
    return _normalize_news(payload, normalized_symbol)

@app.websocket("/v1/live")
async def live_market(websocket: WebSocket):
    authorization = websocket.headers.get("authorization")
    try:
        _require_client_auth(authorization)
    except HTTPException:
        await websocket.close(code=4401)
        return
    await websocket.accept()
    try:
        first = await asyncio.wait_for(websocket.receive_json(), timeout=10.0)
        if not isinstance(first, dict) or first.get("action") != "subscribe" or not isinstance(first.get("symbols"), list):
            await websocket.close(code=4400)
            return
        raw_symbols = first["symbols"]
        if len(raw_symbols) > LIVE_MAX_SYMBOLS:
            await websocket.close(code=4409)
            return
        symbols = list(dict.fromkeys(_normalize_symbol(str(x)) for x in raw_symbols))
        if not symbols:
            await websocket.close(code=4400)
            return
        sequence = 0
        tick_window_started = time.monotonic()
        tick_count = 0
        while True:
            now_mono = time.monotonic()
            if now_mono - tick_window_started >= 60.0:
                tick_window_started = now_mono
                tick_count = 0
            if tick_count >= LIVE_MAX_TICKS_PER_MINUTE:
                await websocket.close(code=4429)
                return
            cycle_start = now_mono
            for symbol in symbols:
                try:
                    q = await _quote_impl(symbol)
                    sequence += 1
                    tick_count += 1
                    await websocket.send_json({
                        "type":"tick", "sequence":sequence, "symbol":q.symbol, "market":q.market,
                        "price":q.price, "changePct":q.dailyChangePct, "volume":q.volume,
                        "timestamp":q.exchangeTimestamp, "receivedAt":q.receivedAt, "source":q.source,
                        "realtime":q.realtime, "delaySeconds":q.delaySeconds,
                        "currentSessionIncluded":q.currentSessionIncluded
                    })
                except HTTPException as exc:
                    await websocket.send_json({"type":"error","symbol":symbol,"detail":exc.detail})
            elapsed = time.monotonic() - cycle_start
            await asyncio.sleep(max(0.25, 1.0 - elapsed))
    except (WebSocketDisconnect, asyncio.TimeoutError):
        return
